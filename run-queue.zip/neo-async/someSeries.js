'use strict';

module.exports = require('./async').someSeries;

module.exports = require('./src/normalizeWheel.js');

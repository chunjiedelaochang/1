var throttle = require('./throttle');
var debounce = require('./debounce');

module.exports = {
	throttle: throttle,
	debounce: debounce
};

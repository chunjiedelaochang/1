/* eslint-disable
  strict
*/

'use strict';

const validateOptions = require('./validateOptions');

module.exports = validateOptions;

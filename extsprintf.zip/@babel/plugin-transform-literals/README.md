# @babel/plugin-transform-literals

> Compile ES2015 unicode string and number literals to ES5

See our website [@babel/plugin-transform-literals](https://babeljs.io/docs/en/next/babel-plugin-transform-literals.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-literals
```

or using yarn:

```sh
yarn add @babel/plugin-transform-literals --dev
```

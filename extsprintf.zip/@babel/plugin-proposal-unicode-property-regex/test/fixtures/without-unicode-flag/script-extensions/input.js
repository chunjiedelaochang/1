var regex = /\p{Script_Extensions=Anatolian_Hieroglyphs}/u;

var regex = /[\u{14400}-\u{14646}]/u;
